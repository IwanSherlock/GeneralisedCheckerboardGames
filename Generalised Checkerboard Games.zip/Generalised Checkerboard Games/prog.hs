import Prelude
import Data.Ord
import Data.List
import Debug.Trace
import System.Random
import GHC.Generics (Generic)

import qualified Data.HashMap.Strict as HashMap
import Data.Hashable (Hashable, hashWithSalt)
import Control.Monad.State
import Control.Monad.Identity (runIdentity)

seed::Int
seed = 40

generator = mkStdGen seed

giveRandomElement :: [(Move, Coords)] -> (Move, Coords)
giveRandomElement l = l !! rand where
  n = length l
  (rand, _) = randomR (0,(n-1)) generator

main = do
    putStrLn $ "Play : Chess or Hexapawn"
    command <- getLine
    putStrLn $ "enter size: "
    szNM  <- getLine
    let n = read $ (words szNM) !! 0 :: Int
    let m = read $ (words szNM) !! 1 :: Int
    do (case command of
        "hexapawn" -> runGame (brdCustomHexapawn n m) White movesHexapawn (winsCustomHexapawn m)
        "stricthexa" -> runGame (brdCustomHexapawn n m) White movesHexapawn (winsCustomStrictHexapawn m)
        "chess" -> runGame brdChess White moves_chess wins_chess
        "archerpawn" -> runGame (brdCustomArcherPawn n m) White movesArcherpawn (winsCustomHexapawn m))

data Player = White | Black | None

data WinType = WhiteWin | BlackWin | Draw | NoWin
instance Eq Player where
    (==) White White = True
    (==) Black Black = True
    (==) None None = True
    (==) _ _ = False
instance Eq WinType where
    (==) WhiteWin WhiteWin = True
    (==) BlackWin BlackWin = True
    (==) Draw Draw = True
    (==) NoWin NoWin = True
    (==) _ _ = False

data Piece  = Piece {name :: Char, player :: Player}
instance Show Piece where
    show p = playerCol (player p) ++ [name p] ++ "\ESC[37m"
instance Eq Piece where
    (==) p1 p2 = name p1 == '~' || name p2 == '~' || ((name p1 == '#' || name p2 == '#') && (player p1 == player p2)) || ((name p1 == name p2) && (player p1 == player p2))

type Board   = [[Piece]]
type Pattern = [[Piece]]
type Coords  = (Int, Int)

data Move = Move {move :: String, plPiece :: Player, mvPiece :: Piece, from :: Pattern, to :: Pattern}
instance Show Move where
    show m = move m
data WinPattern = WinPattern {winName :: String, wType :: WinType, pattern :: Pattern}

type WinCondition = Board -> Player -> [Move] -> WinType

data MiniMaxState = MiniMaxState {num :: Int, alpha :: Float, beta :: Float}
instance Eq MiniMaxState where
    (==) m1 m2 = num m1 == num m2
instance Ord MiniMaxState where
  (MiniMaxState s1 _ _) `compare` (MiniMaxState s2 _ _) = s1 `compare` s2

type TranspositionTable = HashMap.HashMap String (Float, Int)
initialTranspositionTable :: TranspositionTable
initialTranspositionTable = HashMap.empty

maxDepth :: Int
maxDepth = 1000

normal :: Float
normal = 200

runGame :: Board -> Player -> [Move] -> [WinCondition] -> IO ()
runGame b pl ms ws = do
    putStrLn (showBrd b)
    putStrLn $ "Move for " ++ showPlayer pl ++ ": "
    command  <- getLine
    if command == "help" then do
        putStrLn "Enter moves in format [MOVE] [X] [Y]\n"
        putStrLn $ showMoves ms
        putStrLn "\n Legal Moves:\n"
        putStrLn $ showMovesCoords $ legalMoves b pl ms
        runGame b pl ms ws
    else do
        if command == "ai" then do
            let (((move, coords), (val, n)), _) = runState (bestMoveWithTT maxDepth b pl ms ws (-1/0) (1/0)) initialTranspositionTable
            let b' = makeMove b move coords
                bf = (fromIntegral n) ** (1 / (fromIntegral (maxDepth+1)))

            putStrLn $ showMovesCoords [(move, coords)]
            putStrLn $ "Position Value: " ++ showMat val
            putStrLn $ "Game States Analysed : " ++ show n
            putStrLn $ "Branching Factor: " ++ show (fromIntegral (round (bf * 1000)) / 1000)

            let win = checkWin b' (otherPlayer pl) ms ws
            if win == NoWin then do
                runGame b' (otherPlayer pl) ms ws
            else do
                putStrLn (showBrd b')
                putStrLn $ showWinType win
            
        else do
            if command == "rand" then do

                let moves = legalMoves b pl ms
                let mc = giveRandomElement moves
                let b' = makeMove b (fst mc) (snd mc)
                let win = checkWin b' (otherPlayer pl) ms ws
                if win == NoWin then do
                    runGame b' (otherPlayer pl) ms ws
                else do
                    putStrLn (showBrd b')
                    putStrLn $ showWinType win
            else do
                let move = getMove ms ((words command) !! 0) :: Move
                let x = read ((words command) !! 1) :: Int
                let y = read ((words command) !! 2) :: Int
                let b' = makeMove b move (y,x)
                let win = checkWin b' (otherPlayer pl) ms ws
                if win == NoWin then do
                    runGame b' (otherPlayer pl) ms ws
                else do
                    putStrLn (showBrd b')
                    putStrLn $ showWinType win

showMat :: Float -> String
showMat v
    | v >= 1 = "W-" ++ show (maxDepth + 1 - round v)
    | v <= -1 = "B-" ++ show (maxDepth + 1 + round v)
    | otherwise = show v

pruning :: Bool
pruning = True

-- Minimax with Transposition Table Support
minimaxWithTT :: Int -> Board -> Player -> [Move] -> [WinCondition] -> Float -> Float -> State TranspositionTable (Float, Int)
minimaxWithTT depth brd pl ms ws alpha beta = do
    tt <- get
    case HashMap.lookup (show brd) tt of
        Just (eval, d) | d >= depth -> return (eval, 1) -- Use cached value if depth is sufficient
        _ -> do
            let win = checkWin brd pl ms ws
            result <- if win /= NoWin
                      then return (evaluateWin win * (fromIntegral depth + 1), 1)
                      else if depth == 0
                           then return (heuristic brd pl ms, 1)
                           else if pl == White
                                then maxValueTT depth brd ms ws alpha beta
                                else minValueTT depth brd ms ws alpha beta
            modify (HashMap.insert (show brd) result)
            return result

-- Helper functions for maximizing and minimizing players
maxValueTT :: Int -> Board -> [Move] -> [WinCondition] -> Float -> Float -> State TranspositionTable (Float, Int)
maxValueTT depth brd ms ws alpha beta = go alpha moves (-1/0) 0
  where
    moves = legalMoves brd White ms
    go _ [] best n = return (best, n)
    go a (m:mms) best n = do
        let b' = makeMove brd (fst m) (snd m)
        score <- minimaxWithTT (depth - 1) b' Black ms ws a beta
        let newVal = fst score
            newNum = snd score
            newBest = max best newVal
            newAlpha = max a newBest
        if newAlpha >= beta
            then return (newBest, n + newNum)
            else go newAlpha mms newBest (n + newNum)

minValueTT :: Int -> Board -> [Move] -> [WinCondition] -> Float -> Float -> State TranspositionTable (Float, Int)
minValueTT depth brd ms ws alpha beta = go beta moves (1/0) 0
  where
    moves = legalMoves brd Black ms
    go _ [] best n = return (best, n)
    go b (m:mms) best n = do
        let b' = makeMove brd (fst m) (snd m)
        score <- minimaxWithTT (depth - 1) b' White ms ws alpha b
        let newVal = fst score
            newNum = snd score
            newBest = min best newVal
            newBeta = min b newBest
        if alpha >= newBeta
            then return (newBest, n + newNum)
            else go newBeta mms newBest (n + newNum)

bestMoveWithTT :: Int -> Board -> Player -> [Move] -> [WinCondition] -> Float -> Float -> State TranspositionTable ((Move, Coords), (Float, Int))
bestMoveWithTT depth brd pl ms ws alpha beta
    | pl == White = do
        movesEval <- mapM moveEval moves
        return $ argmax (fst . snd) movesEval
    | otherwise   = do
        movesEval <- mapM moveEval moves
        return $ argmin (fst . snd) movesEval
  where
    moves = legalMoves brd pl ms
    moveEval :: (Move, Coords) -> State TranspositionTable ((Move, Coords), (Float, Int))
    moveEval move = do
        let newBoard = makeMove brd (fst move) (snd move)
        result <- minimaxWithTT depth newBoard (otherPlayer pl) ms ws alpha beta
        return (move, result)
-- Valence
argmax :: (a -> Float) -> [a] -> a
argmax f xs = maximumBy (comparing f) xs

argmin :: (a -> Float) -> [a] -> a
argmin f xs = minimumBy (comparing f) xs

heuristic :: Board -> Player -> [Move] -> Float
heuristic b _ ms = (pieceHeuristic) / normal
    where 
        moveHeuristic = fromIntegral $ (length (legalMoves b White ms)) - (length (legalMoves b Black ms))
        pieceHeuristic = sum $ fmap (pieceValue ms) $ concat b

pieceValue :: [Move] -> Piece -> Float
pieceValue ms pl
    | pl == empty = 0
    | otherwise = fromIntegral $ length [m | m <- ms, mvPiece m == pl] * if player pl == White then 1 else -1

evaluateWin :: WinType -> Float
evaluateWin WhiteWin = 1.0
evaluateWin BlackWin = -1.0
evaluateWin Draw = 0.0
evaluateWin _ = 0.0

showWinType :: WinType -> String
showWinType WhiteWin = "\nWin for White"
showWinType BlackWin = "\nWin for Black"
showWinType Draw = "\nDraw"
showWinType _ = "\nNo win found."

showWin :: WinPattern -> String
showWin w = showWinType (wType w) ++ winName w

checkWin :: Board -> Player -> [Move] -> [WinCondition] -> WinType
checkWin _ _ _ [] = NoWin
checkWin b p ms (w:ws) = if wp /= NoWin then wp else checkWin b p ms ws
    where wp = w b p ms

checkWinPattern :: WinPattern -> WinCondition
checkWinPattern _ [] _ _ = NoWin
checkWinPattern w (r:rs) _ _ = if length wp > 0 then wType w else NoWin
    where 
        wp = [(y,x) | y <- [0..(length rs)], x <- [0..(length r - 1)], checkPattern (r:rs) (pattern w) (y,x)]

showMoves :: [Move] -> String
showMoves [] = ""
showMoves (x:xs) = move x ++ "\n" ++ showMoves xs

showMovesCoords :: [(Move, Coords)] -> String
showMovesCoords [] = ""
showMovesCoords ((m,(y,x)):xs) = move m ++ " at " ++ show x ++ "," ++ show y ++ "\n" ++ showMovesCoords xs

getMove :: [Move] -> String -> Move
getMove (m:[]) _ = m
getMove (m:ms) s = if move m == s then m else getMove ms s

legalMoves :: Board -> Player -> [Move] -> [(Move, Coords)]
legalMoves (r:rs) pl ms = [(m, (y,x)) | m <- ms, y <- [0..(length rs)], x <- [0..(length r - 1)], checkPattern (r:rs) (from m) (y,x), pl == plPiece m]

makeMove :: Board -> Move -> Coords -> Board
makeMove b m cs = insertPattern b (to m) cs

insertPattern :: Board -> Pattern -> Coords -> Board
insertPattern b [] _ = b
insertPattern b (r:rs) (y,x) = insertPattern (insertRow b r (y,x)) rs (y+1,x)

insertRow :: Board -> [Piece] -> Coords -> Board
insertRow b [] _ = b
insertRow b (p:ps) (y,x) = insertRow (setCell b (y,x) p) ps (y,x+1) 

setCell :: Board -> Coords -> Piece -> Board
setCell b (y,x) p = if name p == '~' then b else
    b1 ++ [r1 ++ [p] ++ r2] ++ b2
    where b1 = take y b
          b2 = drop (y+1) b
          r = b !! y
          r1 = take x r
          r2 = drop (x+1) r

checkPattern :: Board -> Pattern -> Coords -> Bool
checkPattern (br:brs) (r:rs) (y,x) = (fmap (cut x (length r)) (cut y (length rs + 1) (br:brs))) == (r:rs)

playerCol :: Player -> String
playerCol White = "\ESC[93m"
playerCol Black = "\ESC[37m"
playerCol None = "\ESC[31m"

otherPlayer :: Player -> Player
otherPlayer White = Black
otherPlayer Black = White

showPlayer :: Player -> String
showPlayer White = "White"
showPlayer Black = "Black"

showBrd :: Board -> String
showBrd (r:rs) = "┌───" ++ (duplicate "┬───" (length r - 1)) ++ "┐\n" ++ showBrdCenter (r:rs)

showBrdCenter :: Board -> String
showBrdCenter [r] = "│ " ++ showBrdRow r ++ "\n└───" ++ (duplicate "┴───" (length r - 1)) ++ "┘\n"
showBrdCenter (r:rs) = "│ " ++ showBrdRow r ++ "\n├───" ++ (duplicate "┼───" (length r - 1)) ++ "┤\n" ++ showBrdCenter rs

showBrdRow :: [Piece] -> String
showBrdRow (p:ps) = show p  ++ " │ " ++ showBrdRow ps
showBrdRow [] = ""

brdCustomHexapawn :: Int -> Int -> Board
brdCustomHexapawn n m = [take n (cycle [pawn_B])] ++ take (m-2) (cycle [take n (cycle [empty])]) ++ [take n (cycle [pawn_W])]

brdCustomArcherPawn :: Int -> Int -> Board
brdCustomArcherPawn n m = [take n (cycle [archer_B])] ++ [take n (cycle [pawn_B])] ++ take (m-4) (cycle [take n (cycle [empty])]) ++ [take n (cycle [pawn_W])] ++ [take n (cycle [archer_W])]

winsCustomHexapawn :: Int -> [WinCondition]
winsCustomHexapawn m = [pW_win, pB_win, hexa_draw]
    where
        pB_win = checkWinPattern $ WinPattern "Black advancement" BlackWin (take (m-1) (cycle [[anyPiece]]) ++ [[anyBlack]])
        pW_win = checkWinPattern $ WinPattern "White advancement" WhiteWin ([[anyWhite]] ++ take (m-1) (cycle [[anyPiece]]))

winsCustomStrictHexapawn :: Int -> [WinCondition]
winsCustomStrictHexapawn m = [pW_win, pB_win, hexa_draw_strict]
    where
        pB_win = checkWinPattern $ WinPattern "Black advancement" BlackWin (take (m-1) (cycle [[anyPiece]]) ++ [[anyBlack]])
        pW_win = checkWinPattern $ WinPattern "White advancement" WhiteWin ([[anyWhite]] ++ take (m-1) (cycle [[anyPiece]]))


brdHexapawn :: Board
brdHexapawn = [
    [pawn_B, pawn_B, pawn_B],
    [empty, empty, empty],
    [pawn_W, pawn_W, pawn_W]]

movesHexapawn :: [Move]
movesHexapawn = [pawn_B_move, pawn_W_move, pawn_B_capl, pawn_B_capr, pawn_W_capl, pawn_W_capr]

movesArcherpawn :: [Move]
movesArcherpawn = movesHexapawn ++ [archer_B_move, archer_B_cap, archer_W_cap, archer_W_move]

winsHexapawn :: [WinCondition]
winsHexapawn = [pawn_B_win, pawn_W_win, hexa_draw]

-- Hard coded moves
pawn_B_move = Move "move_bp" Black pawn_B [[pawn_B],[empty]] [[empty],[pawn_B]]
pawn_W_move = Move "move_wp" White pawn_W [[empty],[pawn_W]] [[pawn_W],[empty]]

pawn_B_capl = Move "capl_bp" Black pawn_B [[anyPiece, pawn_B],[pawn_W, anyPiece]] [[anyPiece, empty],[pawn_B, anyPiece]]
pawn_W_capl = Move "capl_wp" White pawn_W [[pawn_B, anyPiece],[anyPiece, pawn_W]] [[pawn_W, anyPiece],[anyPiece, empty]]
pawn_B_capr = Move "capr_bp" Black pawn_B [[pawn_B, anyPiece],[anyPiece, pawn_W]] [[empty, anyPiece],[anyPiece, pawn_B]]
pawn_W_capr = Move "capr_wp" White pawn_W [[anyPiece, pawn_B],[pawn_W, anyPiece]] [[anyPiece, pawn_W],[empty, anyPiece]]

archer_B_cap = Move "cap_ba" Black archer_B [[archer_B],[anyPiece],[anyWhite]] [[empty],[anyPiece],[archer_B]]
archer_W_cap = Move "cap_ba" White archer_W [[anyBlack],[anyPiece],[archer_W]] [[archer_W],[anyPiece],[empty]]
archer_B_move = Move "move_ba" Black archer_B [[archer_B],[empty]] [[empty],[archer_B]]
archer_W_move = Move "move_wa" White archer_W [[empty],[archer_W]] [[archer_W],[empty]]

-- Hard coded win conditions
pawn_W_win = checkWinPattern $ WinPattern "White pawn advancement" WhiteWin [[pawn_W],[anyPiece],[anyPiece]]
pawn_B_win = checkWinPattern $ WinPattern "Black pawn advancement" BlackWin [[anyPiece],[anyPiece],[pawn_B]]

hexa_draw :: WinCondition
hexa_draw b pl ms = if length (legalMoves b pl ms) == 0 then Draw else NoWin

hexa_draw_strict :: WinCondition
hexa_draw_strict b pl ms = if length (legalMoves b pl ms) == 0 then otherWin else NoWin
    where
        otherWin = if pl == White then BlackWin else WhiteWin

brdChess :: Board
brdChess = [
    [rook_B, knight_B, bishop_B, queen_B, king_B, bishop_B, knight_B, rook_B],
    [pawn_B, pawn_B, pawn_B, pawn_B, pawn_B, pawn_B, pawn_B, pawn_B],
    [empty, empty, empty, empty, empty, empty, empty, empty],
    [empty, empty, empty, empty, empty, empty, empty, empty],
    [empty, empty, empty, empty, empty, empty, empty, empty],
    [empty, empty, empty, empty, empty, empty, empty, empty],
    [pawn_W, pawn_W, pawn_W, pawn_W, pawn_W, pawn_W, pawn_W, pawn_W],
    [rook_W, knight_W, bishop_W, queen_W, king_W, bishop_W, knight_W, rook_W]]

wins_chess :: [WinCondition]
wins_chess = [hexa_draw]

moves_chess :: [Move]
moves_chess = [pB_capl, pB_capr, pB_jump, pB_move, pW_capl, pW_capr, pW_jump, pW_move]

-- Chess moves
-- Pawn moves
pB_move = Move "move_bp" Black pawn_B [[pawn_B],[empty]] [[empty],[pawn_B]]
pW_move = Move "move_wp" White pawn_W [[empty],[pawn_W]] [[pawn_W],[empty]]
pB_jump = Move "jump_bp" Black pawn_B [[pawn_B],[empty],[empty],[anyPiece],[anyPiece],[anyPiece],[anyPiece]] [[empty], [empty],[pawn_B],[anyPiece],[anyPiece],[anyPiece],[anyPiece]]
pW_jump = Move "jump_wp" White pawn_W [[anyPiece],[anyPiece],[anyPiece],[anyPiece], [empty], [empty],[pawn_W]] [[anyPiece],[anyPiece],[anyPiece],[anyPiece], [pawn_W], [empty], [empty]]

pB_capl = Move "capl_bp" Black pawn_B [[anyPiece, pawn_B],[anyWhite, anyPiece]] [[anyPiece, empty],[pawn_B, anyPiece]]
pW_capl = Move "capl_wp" White pawn_W [[anyBlack, anyPiece],[anyPiece, pawn_W]] [[pawn_W, anyPiece],[anyPiece, empty]]
pB_capr = Move "capr_bp" Black pawn_B [[pawn_B, anyPiece],[anyPiece, anyWhite]] [[empty, anyPiece],[anyPiece, pawn_B]]
pW_capr = Move "capr_wp" White pawn_W [[anyPiece, anyBlack],[pawn_W, anyPiece]] [[anyPiece, pawn_W],[empty, anyPiece]]


-- Pieces required for all games, any used for pattern matching
anyPiece = Piece '~' None
anyWhite = Piece '#' White
anyBlack = Piece '#' Black
empty    = Piece ' ' None

--Hard coded pieces
archer_W = Piece 'A' White
pawn_W   = Piece 'P' White
rook_W   = Piece 'R' White
knight_W = Piece 'N' White
bishop_W = Piece 'B' White
queen_W  = Piece 'Q' White
king_W   = Piece 'K' White

archer_B = Piece 'A' Black
pawn_B   = Piece 'P' Black
rook_B   = Piece 'R' Black
knight_B = Piece 'N' Black
bishop_B = Piece 'B' Black
queen_B  = Piece 'Q' Black
king_B   = Piece 'K' Black

duplicate :: String -> Int -> String
duplicate s n = concat $ replicate n s

cut :: Int -> Int -> [a] -> [a]
cut m n = take n . drop m